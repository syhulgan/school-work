#pragma once

//struct to store patient records
struct PatientRecords
{
  string firstName = "";
  string lastName = "";
  char Gender = 'Z';
  int Age = 0;
  string birthMonth = "";
  int Birthday = 0;
  int birthYear = 0;
  string Symptoms = "";
};
